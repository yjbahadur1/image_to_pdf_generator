/* ================================================================
   KPMG Contact Sheet Generator  |  app.js
   Page 1 : 6 images + info panel (3-col grid)
   Page 2+: 8 images per page (4×2 grid), continued header
   ================================================================ */
'use strict';

/* ── PAGE DIMENSIONS (PPT Widescreen 16:9) ── */
const PW   = 338.67;   /* mm */
const PH   = 190.5;    /* mm */

/* ── TILE ASPECT for 4×2 grid with standard margins ── */
/* cellW = (338.67 - 14*2 - 5*3) / 4 = 73.92mm
   cellH = (190.5 - 38(title) - 8(footer) - 10(mYtop) - 10(mYbot) - 5*1) / 2 = ~54.75mm
   imgH  = cellH - 7(desc) = ~47.75mm
   ASPECT = cellW / imgH = ~1.548  (landscape-ish) */
const TILE_ASPECT = 1.548;   /* used by adjuster crop frame */

/* ── KPMG COLOURS ── */
const KPMG_BLUE  = [0, 51, 160];
const KPMG_PINK  = [214, 0, 110];

/* ── STATE ── */
let images   = [];   /* [{ id, name, dataUrl, desc, crop }] */
let dragSrc  = null;
let adj      = null;

/* ── BOOT ── */
document.addEventListener('DOMContentLoaded', () => {
  setTodayDate();
  bindFileInput();
  bindDropZone();
  bindDeliverables();
  bindAutoResizeTextareas();
  updateStats();
});

function bindAutoResizeTextareas() {
  document.querySelectorAll('.form-textarea-auto').forEach(ta => {
    /* set initial height to content */
    ta.style.height = 'auto';
    ta.addEventListener('input', () => {
      ta.style.height = 'auto';
      ta.style.height = (ta.scrollHeight) + 'px';
    });
  });
}

/* ── DATE ── */
function setTodayDate() {
  const now = new Date();
  document.getElementById('jobDate').value =
    now.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  const y = now.getFullYear(), m = String(now.getMonth()+1).padStart(2,'0'), d = String(now.getDate()).padStart(2,'0');
  document.getElementById('jobDatePicker').value = `${y}-${m}-${d}`;
  document.getElementById('jobDatePicker').addEventListener('change', e => {
    if (!e.target.value) return;
    const [yr, mo, da] = e.target.value.split('-').map(Number);
    document.getElementById('jobDate').value =
      new Date(yr, mo-1, da).toLocaleDateString('en-GB', { day:'numeric', month:'long', year:'numeric' });
  });
}

/* ── DELIVERABLES ── */
function bindDeliverables() {
  document.querySelectorAll('.del-check').forEach(el => {
    el.addEventListener('click', () => {
      el.classList.toggle('checked');
      const isChecked = el.classList.contains('checked');

      /* Clear validation error on any selection */
      document.getElementById('deliverableError').classList.add('hidden');

      /* Show/hide the "Other" text row */
      if (el.dataset.val === 'other') {
        const row   = document.getElementById('delOtherRow');
        const input = document.getElementById('delOtherInput');
        if (isChecked) {
          row.classList.remove('hidden');
          setTimeout(() => input.focus(), 60);
        } else {
          row.classList.add('hidden');
          input.value = '';
        }
      }
    });
  });
}

function getDeliverables() {
  const vals = [];
  document.querySelectorAll('.del-check.checked').forEach(el => {
    if (el.dataset.val === 'other') {
      const v = document.getElementById('delOtherInput').value.trim();
      if (v) vals.push(v);
      else vals.push('Other');
    } else {
      vals.push(el.dataset.label);
    }
  });
  return vals;
}

/* ── FILE INPUT ── */
function bindFileInput() {
  const inp = document.getElementById('fileInput');
  inp.addEventListener('change', e => { handleFiles(Array.from(e.target.files)); inp.value = ''; });
}
function bindDropZone() {
  const dz = document.getElementById('dropZone');
  dz.addEventListener('click', () => document.getElementById('fileInput').click());
  dz.addEventListener('dragover',  e => { e.preventDefault(); dz.classList.add('drag-over'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
  dz.addEventListener('drop', e => {
    e.preventDefault(); dz.classList.remove('drag-over');
    handleFiles(Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/')));
  });
}
function handleFiles(files) {
  const valid = files.filter(f => f.type.startsWith('image/'));
  if (!valid.length) { showToast('No valid image files', 'error'); return; }
  valid.forEach(file => {
    const r = new FileReader();
    r.onload = ev => {
      const uid      = Date.now() + Math.random();
      const autoDesc = extractDescFromFilename(file.name);  /* stock ID from filename */
      const assetId  = extractAdobeStockId(file.name);       /* numeric ID if Adobe Stock */

      const entry = { id: uid, name: file.name, dataUrl: ev.target.result,
                      desc: autoDesc, title: '', crop: null };
      images.push(entry);
      renderGrid();
      updateStats();

      /* Pipeline — runs in sequence, each step fills gaps left by previous */
      enrichImageEntry(uid, ev.target.result, assetId, autoDesc);
    };
    r.readAsDataURL(file);
  });
}

/* Full enrichment pipeline for one image entry */
async function enrichImageEntry(uid, dataUrl, assetId, autoDesc) {
  const obj = images.find(im => im.id === uid);
  if (!obj) return;

  /* ── STEP 1: Read embedded metadata (IPTC / XMP / EXIF) ── */
  const meta = await extractImageMetadata(dataUrl);

  if (meta.title)       { obj.title = meta.title;             }
  if (meta.description) {
    if (!obj.desc)      { obj.desc  = meta.description;       }
    if (!obj.title)     { obj.title = meta.description;       }
  }

  /* ── STEP 2: If IPTC keywords present and no title yet, use them ── */
  if (!obj.title && meta.keywords && meta.keywords.length) {
    obj.title = meta.keywords.slice(0, 5).join(', ');
  }

  renderGrid();  /* show what we found so far */

  /* ── STEP 3: If still no title AND we have an Adobe Stock asset ID,
     fetch the real title + description from Adobe Stock search API ── */
  if (!obj.title && assetId) {
    obj.fetching = true;
    renderGrid();  /* show loading indicator */

    const stockMeta = await fetchAdobeStockMeta(assetId);
    obj.fetching = false;

    if (stockMeta) {
      if (stockMeta.title && !obj.title)            obj.title = stockMeta.title;
      if (stockMeta.description && !obj.desc)       obj.desc  = stockMeta.description;
      else if (stockMeta.description && !obj.title) obj.title = stockMeta.description;
    }

    renderGrid();
  }
}

/* Extract the Adobe Stock numeric asset ID from a filename.
   Works on: AdobeStock_272252920.jpg, AdobeStock_272252920_Preview.jpg,
             adobe_stock_272252920_watermark.jpg, etc. */
function extractAdobeStockId(filename) {
  const base = filename.replace(/\.[^.]+$/, '');
  /* Adobe Stock specific patterns */
  const m = base.match(/AdobeStock[_\-](\d{6,})/i)
         || base.match(/adobe[_\-]stock[_\-](\d{6,})/i)
         || base.match(/stock[_\-](\d{6,})/i);
  if (m) return m[1];
  /* Fallback: any 6+ digit run */
  const n = base.match(/(\d{8,})/);
  return n ? n[1] : null;
}

/* Fetch real title/description from Adobe Stock search API.
   Uses the public /Rest/Media/1/Search/Files endpoint — no API key needed for
   basic asset lookup by media_id. Returns { title, description } or null. */
async function fetchAdobeStockMeta(assetId) {
  /* Try multiple API approaches — Adobe changes endpoints periodically */
  const strategies = [
    () => tryAdobeOEmbed(assetId),
    () => tryAdobeSearchAPI(assetId),
  ];
  for (const strategy of strategies) {
    try {
      const result = await strategy();
      if (result && result.title) return result;
    } catch (e) { /* try next */ }
  }
  console.warn('All Adobe Stock API lookups failed for ID', assetId);
  return null;
}

/* Strategy 1: Adobe Stock oEmbed endpoint (most reliable, no key needed) */
async function tryAdobeOEmbed(assetId) {
  /* The oembed endpoint accepts asset URLs and returns title/description */
  const assetUrl = encodeURIComponent(`https://stock.adobe.com/images/asset/${assetId}`);
  const url = `https://stock.adobe.com/oembed?url=${assetUrl}&format=json`;
  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!res.ok) return null;
  const data = await res.json();
  if (!data) return null;
  return {
    title:       (data.title || '').trim() || null,
    description: (data.description || data.author_name || '').trim() || null,
  };
}

/* Strategy 2: Adobe Stock Content Delivery API (public, no key required) */
async function tryAdobeSearchAPI(assetId) {
  const url = `https://stock.adobe.com/Rest/Media/1/Search/Files` +
              `?search_parameters[media_id]=${assetId}` +
              `&result_columns[]=title&result_columns[]=description&result_columns[]=keywords` +
              `&search_parameters[limit]=1`;

  const res = await fetch(url, {
    headers: {
      'Accept':     'application/json',
      'X-Product':  'ContactSheetGen/1.0',
      'X-Api-Key':  'StockClient',
    }
  });
  if (!res.ok) return null;
  const data = await res.json();
  const file  = data?.files?.[0];
  if (!file) return null;
  return {
    title:       (file.title       || '').trim() || null,
    description: (file.description || '').trim() || null,
  };
}

/* Extract a description string from the image filename */
function extractDescFromFilename(filename) {
  const base = filename.replace(/\.[^.]+$/, '');
  /* Adobe Stock: AdobeStock_272252920 -> show real number to user */
  const adobeMatch = base.match(/AdobeStock[_\-](\d+)/i);
  if (adobeMatch) {
    return 'Adobe Stock or Media ID #' + adobeMatch[1];
  }
  /* Any 6+ digit number in filename */
  const numMatch = base.match(/(\d{6,})/);
  if (numMatch) {
    return 'Adobe Stock or Media ID #' + numMatch[1];
  }
  return '';
}

/* ═══════════════════════════════════════════════════════════════
   Read ALL metadata from image bytes — title AND description.
   Returns { title, description } — both may be null if not found.

   Sources checked (in priority order):
   TITLE:       IPTC 2:05 (Object Name)
                → XMP dc:title → XMP photoshop:Headline
   DESCRIPTION: IPTC 2:120 (Caption/Abstract)
                → XMP dc:description → XMP Iptc4xmpCore:Description
                → EXIF ImageDescription (tag 0x010E)
                → XMP dc:subject (keywords joined as fallback)
═══════════════════════════════════════════════════════════════ */
async function extractImageMetadata(dataUrl) {
  const result = { title: null, description: null, keywords: [] };
  try {
    const base64 = dataUrl.split(',')[1];
    if (!base64) return result;
    const binary = atob(base64);
    const bytes  = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);

    if (bytes[0] !== 0xFF || bytes[1] !== 0xD8) return result;

    let i = 2;
    while (i < bytes.length - 4) {
      if (bytes[i] !== 0xFF) { i++; continue; }
      const marker = bytes[i + 1];
      const segLen = (bytes[i + 2] << 8) | bytes[i + 3];
      if (segLen < 2) { i += 2; continue; }

      /* APP13 — IPTC */
      if (marker === 0xED) {
        const seg  = bytes.slice(i + 4, i + 2 + segLen);
        const iptc = parseAllIptc(seg);
        if (iptc.title && !result.title)                   result.title       = iptc.title;
        if (iptc.description && !result.description)       result.description = iptc.description;
        if (iptc.keywords && iptc.keywords.length)         result.keywords    = iptc.keywords;
      }

      /* APP1 — XMP or EXIF */
      if (marker === 0xE1 && segLen > 30) {
        const seg    = bytes.slice(i + 4, i + 2 + segLen);
        const hdrStr = new TextDecoder('latin1').decode(seg.slice(0, 50));

        if (hdrStr.includes('http://ns.adobe.com/xap/')) {
          let xmlStart = 0;
          for (let k = 0; k < Math.min(60, seg.length); k++) {
            if (seg[k] === 0x00) { xmlStart = k + 1; break; }
          }
          const xml = new TextDecoder('utf-8').decode(seg.slice(xmlStart));
          const xmp = parseAllXmp(xml);
          if (xmp.title && !result.title)             result.title       = xmp.title;
          if (xmp.description && !result.description) result.description = xmp.description;
        }

        if (seg[0]===0x45 && seg[1]===0x78 && seg[2]===0x69 && seg[3]===0x66) {
          const exifDesc = parseExifImageDescription(seg);
          if (exifDesc && !result.description) result.description = exifDesc;
        }
      }

      i += 2 + segLen;
    }
  } catch (e) { console.warn('Metadata parse error:', e); }
  return result;
}

/* Keep old function name as alias */
async function extractImageTitle(dataUrl) {
  const meta = await extractImageMetadata(dataUrl);
  return meta.title;
}

/* Parse ALL useful IPTC fields (title + caption/description) */
function parseAllIptc(seg) {
  const out = { title: null, description: null, keywords: [] };
  try {
    const ps = [0x50,0x68,0x6F,0x74,0x6F,0x73,0x68,0x6F,0x70,0x20,0x33,0x2E,0x30,0x00];
    let offset = 0;
    for (let i = 0; i < Math.min(seg.length - 14, 200); i++) {
      if (ps.every((b, j) => seg[i + j] === b)) { offset = i + 14; break; }
    }
    const dec = new TextDecoder('utf-8');
    while (offset < seg.length - 5) {
      if (seg[offset] !== 0x1C) { offset++; continue; }
      const record  = seg[offset + 1];
      const dataset = seg[offset + 2];
      const dataLen = (seg[offset + 3] << 8) | seg[offset + 4];
      offset += 5;
      if (dataLen <= 0 || offset + dataLen > seg.length) break;
      if (record === 2) {
        const val = dec.decode(seg.slice(offset, offset + dataLen)).trim();
        if (dataset === 0x05 && val && !out.title)       out.title       = val;       /* Object Name */
        if (dataset === 0x78 && val && !out.description) out.description = val;       /* Caption/Abstract */
        if (dataset === 0x69 && val && !out.title)       out.title       = val;       /* Headline → title fallback */
        if (dataset === 0x19 && val)                     out.keywords.push(val);      /* Keywords */
      }
      offset += dataLen;
    }
  } catch (e) {}
  return out;
}

/* Parse ALL useful XMP fields */
function parseAllXmp(xml) {
  const out = { title: null, description: null };
  try {
    const rdfLi = (tag) => {
      const pats = [
        new RegExp('<' + tag + '[^>]*>[^<]*<rdf:li[^>]*>([^<]+)<\/rdf:li>', 'i'),
        new RegExp('<' + tag + '[^>]*>([^<]{3,})<\/' + tag + '>', 'i'),
        new RegExp(tag + '="([^"]{3,})"', 'i'),
      ];
      for (const p of pats) {
        const m = xml.match(p);
        const v = m && m[1] ? m[1].replace(/<[^>]+>/g, '').trim() : null;
        if (v && v.length > 2) return v;
      }
      return null;
    };

    out.title       = rdfLi('dc:title')
                   || rdfLi('photoshop:Headline');
    out.description = rdfLi('dc:description')
                   || rdfLi('Iptc4xmpCore:Description')
                   || rdfLi('photoshop:Caption')
                   || rdfLi('exif:ImageDescription');

    /* Fallback: keywords as description */
    if (!out.description) {
      const kwMatch = xml.match(/<dc:subject[^>]*>([\s\S]*?)<\/dc:subject>/i);
      if (kwMatch) {
        const kws = [...kwMatch[1].matchAll(/<rdf:li[^>]*>([^<]+)<\/rdf:li>/gi)]
                      .map(m => m[1].trim()).filter(Boolean).slice(0, 8);
        if (kws.length >= 2) out.description = kws.join(', ');
      }
    }
  } catch (e) {}
  return out;
}

/* Parse EXIF ImageDescription (tag 0x010E) */
function parseExifImageDescription(seg) {
  try {
    if (seg.length < 12) return null;
    const tiffOff = 6;
    const le = seg[tiffOff] === 0x49;
    const r16 = (o) => le ? (seg[o] | seg[o+1]<<8) : (seg[o]<<8 | seg[o+1]);
    const r32 = (o) => le
      ? ((seg[o] | seg[o+1]<<8 | seg[o+2]<<16 | seg[o+3]<<24)>>>0)
      : ((seg[o]<<24 | seg[o+1]<<16 | seg[o+2]<<8 | seg[o+3])>>>0);

    const ifdOff = tiffOff + r32(tiffOff + 4);
    if (ifdOff + 2 > seg.length) return null;
    const nEntries = r16(ifdOff);

    for (let e = 0; e < nEntries; e++) {
      const eo = ifdOff + 2 + e * 12;
      if (eo + 12 > seg.length) break;
      const tag   = r16(eo);
      const type  = r16(eo + 2);
      const count = r32(eo + 4);
      if (tag === 0x010E && type === 2 && count > 4) {
        const strOff = count <= 4 ? eo + 8 : tiffOff + r32(eo + 8);
        if (strOff + count <= seg.length) {
          const text = new TextDecoder('latin1')
            .decode(seg.slice(strOff, strOff + count - 1)).trim();
          if (text.length > 3) return text;
        }
      }
    }
  } catch (e) {}
  return null;
}

/* Parse IPTC block for Object Name (tag 0x05) = Title */
function parseIptcTitle(seg) {
  try {
    /* Find "Photoshop 3.0" header */
    const photoshopSig = [0x50,0x68,0x6F,0x74,0x6F,0x73,0x68,0x6F,0x70,0x20,0x33,0x2E,0x30,0x00];
    let offset = 0;
    /* Skip to IPTC block after Photoshop sig */
    for (let i=0; i<seg.length-14; i++) {
      if (photoshopSig.every((b,j) => seg[i+j] === b)) { offset = i+14; break; }
    }
    /* Scan IPTC records */
    while (offset < seg.length - 5) {
      if (seg[offset] !== 0x1C) { offset++; continue; }
      const record  = seg[offset+1];
      const dataset = seg[offset+2];
      const dataLen = (seg[offset+3] << 8) | seg[offset+4];
      offset += 5;
      if (record === 2 && dataset === 5 && dataLen > 0) {
        /* Object Name = Title */
        const titleBytes = seg.slice(offset, offset + dataLen);
        const title = new TextDecoder('utf-8').decode(titleBytes).trim();
        if (title) return title;
      }
      offset += dataLen;
    }
  } catch(e) {}
  return null;
}

/* ── GRID ── */
function renderGrid() {
  const grid = document.getElementById('imageGrid');
  grid.innerHTML = '';
  if (!images.length) {
    document.getElementById('dropZone').style.display = '';
    updateStats(); return;
  }
  document.getElementById('dropZone').style.display = 'none';
  images.forEach((imgData, i) => grid.appendChild(buildTile(imgData, i)));
  updateStats();
}

function buildTile(imgData, idx) {
  const tile = mkEl('div', 'img-tile');
  tile.draggable = true;
  tile.addEventListener('dragstart', e => { dragSrc = idx; tile.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; });
  tile.addEventListener('dragend',   () => { tile.classList.remove('dragging'); document.querySelectorAll('.img-tile').forEach(t=>t.classList.remove('drag-over-tile')); });
  tile.addEventListener('dragover',  e => { e.preventDefault(); tile.classList.add('drag-over-tile'); });
  tile.addEventListener('dragleave', () => tile.classList.remove('drag-over-tile'));
  tile.addEventListener('drop', e => {
    e.preventDefault(); tile.classList.remove('drag-over-tile');
    if (dragSrc !== null && dragSrc !== idx) {
      const moved = images.splice(dragSrc, 1)[0];
      images.splice(idx, 0, moved);
      renderGrid();
    }
    dragSrc = null;
  });

  /* thumbnail */
  const thumb = mkEl('div', 'tile-thumb');
  const cv = document.createElement('canvas');
  thumb.appendChild(cv);
  drawThumb(cv, imgData);
  const numBadge = mkEl('div', 'tile-num'); numBadge.textContent = idx+1;
  thumb.appendChild(numBadge);

  /* Description area — shows title (line 1) + stock ID (line 2), no "Description" label */
  const descWrap = mkEl('div', 'tile-desc-wrap');

  /* Title row — shows loading state while API fetch in progress */
  const titleInp = mkEl('input', 'tile-title-input');
  titleInp.type = 'text';
  titleInp.placeholder = imgData.fetching
    ? 'Looking up title from Adobe Stock…'
    : 'Image title (type manually if needed)';
  titleInp.value = imgData.title || '';
  titleInp.disabled = !!imgData.fetching;
  titleInp.addEventListener('input', e => { images[idx].title = e.target.value; });

  /* Stock ID row — editable, auto-populated from filename */
  const stockInp = mkEl('input', 'tile-stock-input');
  stockInp.type = 'text';
  stockInp.placeholder = 'Adobe Stock or Media ID #xxxxxxxx';
  stockInp.value = imgData.desc || '';
  stockInp.addEventListener('input', e => { images[idx].desc = e.target.value; });

  descWrap.append(titleInp, stockInp);

  /* actions */
  const acts = mkEl('div', 'tile-actions');
  const adjB = mkEl('button', 'btn btn-outline'); adjB.innerHTML = ico('sliders')+' Adjust'; adjB.onclick = () => openAdjust(idx);
  const remB = mkEl('button', 'btn btn-danger');  remB.innerHTML = ico('x')+' Remove';       remB.onclick = () => { images.splice(idx,1); renderGrid(); };
  acts.append(adjB, remB);

  tile.append(thumb, descWrap, acts);
  return tile;
}

function drawThumb(canvas, imgData) {
  const W = 220, H = Math.round(W / TILE_ASPECT);
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext('2d');
  const img = new Image();
  img.onload = () => {
    ctx.clearRect(0,0,W,H);
    if (imgData.crop) {
      const c = imgData.crop;
      ctx.drawImage(img, c.sx, c.sy, c.sw, c.sh, 0, 0, W, H);
    } else {
      const sc = Math.max(W/img.width, H/img.height);
      ctx.drawImage(img, (img.width-W/sc)/2, (img.height-H/sc)/2, W/sc, H/sc, 0, 0, W, H);
    }
  };
  img.src = imgData.dataUrl;
}

/* ── BULK AUTO-CROP ── */
function bulkAutoCrop() {
  if (!images.length) { showToast('No images to crop','error'); return; }
  let done = 0;
  images.forEach(imgData => {
    const img = new Image();
    img.onload = () => {
      const W=img.width, H=img.height, ar=W/H;
      let sw,sh,sx,sy;
      if (ar > TILE_ASPECT) { sh=H; sw=H*TILE_ASPECT; sx=(W-sw)/2; sy=0; }
      else { sw=W; sh=W/TILE_ASPECT; sx=0; sy=(H-sh)/2; }
      imgData.crop = {sx,sy,sw,sh};
      if (++done===images.length) { renderGrid(); showToast(`Auto-cropped ${done} images`,'success'); }
    };
    img.src = imgData.dataUrl;
  });
}

/* ── STATS ── */
function updateStats() {
  const n = images.length;
  /* Page 1: up to 6 images; remaining: 8 per page */
  let pages = 0;
  if (n > 0) { pages = 1 + Math.ceil(Math.max(0, n-6) / 8); }
  document.getElementById('statImages').textContent = n;
  document.getElementById('statPages').textContent  = pages;
}

/* ════════════════════════════════════════════════════
   ADJUST MODAL  — crop-frame (image moves under frame)
════════════════════════════════════════════════════ */
function openAdjust(idx) {
  if (adj && adj.raf) cancelAnimationFrame(adj.raf);
  adj = null;
  document.getElementById('adjustModal').classList.remove('hidden');

  const imgData = images[idx];
  const img = new Image();
  img.onload = () => {
    const outer  = document.getElementById('cropCanvasOuter');
    const canvas = document.getElementById('cropCanvas');
    const cW = Math.max(outer.clientWidth||700, 400);
    const cH = Math.max(outer.clientHeight||460, 280);
    canvas.width = cW; canvas.height = cH;

    const padX    = cW * 0.14; const padY = cH * 0.14;
    let   frmW    = cW - padX*2;
    let   frmH    = frmW / TILE_ASPECT;
    const maxFrmH = cH - padY*2;
    if (frmH > maxFrmH) { frmH = maxFrmH; frmW = frmH * TILE_ASPECT; }
    const frmX = (cW - frmW) / 2;
    const frmY = (cH - frmH) / 2;

    const fillZoom = Math.max(frmW/img.width, frmH/img.height);
    const minZoom  = fillZoom * 0.1;

    let zoom, panX, panY;
    if (imgData.crop) {
      const c = imgData.crop;
      zoom = frmW / c.sw;
      panX = frmX - c.sx * zoom;
      panY = frmY - c.sy * zoom;
    } else {
      zoom = fillZoom;
      panX = frmX - (img.width*zoom - frmW)/2;
      panY = frmY - (img.height*zoom - frmH)/2;
    }

    adj = { idx, imgEl:img, cW, cH, frmX, frmY, frmW, frmH, fillZoom, minZoom,
            zoom, panX, panY, dragging:false, lastX:0, lastY:0, raf:null, dirty:true };

    const sl = document.getElementById('zoomSlider');
    sl.min = minZoom; sl.max = fillZoom*10; sl.step = fillZoom/2000; sl.value = zoom;

    startRenderLoop(); bindAdjustEvents();
  };
  img.src = imgData.dataUrl;
}

function startRenderLoop() {
  function loop() { if (!adj) return; if (adj.dirty) { drawAdj(); adj.dirty=false; } adj.raf=requestAnimationFrame(loop); }
  loop();
}

function drawAdj() {
  if (!adj) return;
  const { imgEl, zoom, panX, panY, cW, cH, frmX, frmY, frmW, frmH } = adj;
  const canvas = document.getElementById('cropCanvas');
  const ctx    = canvas.getContext('2d');
  ctx.fillStyle = '#08101e'; ctx.fillRect(0,0,cW,cH);
  ctx.save(); ctx.translate(panX,panY); ctx.scale(zoom,zoom); ctx.drawImage(imgEl,0,0); ctx.restore();
  /* dim outside frame */
  ctx.fillStyle='rgba(0,0,0,0.55)';
  ctx.fillRect(0,0,cW,frmY); ctx.fillRect(0,frmY+frmH,cW,cH-frmY-frmH);
  ctx.fillRect(0,frmY,frmX,frmH); ctx.fillRect(frmX+frmW,frmY,cW-frmX-frmW,frmH);
  /* frame border */
  ctx.strokeStyle='rgba(255,255,255,0.9)'; ctx.lineWidth=1.5; ctx.strokeRect(frmX,frmY,frmW,frmH);
  /* 3×3 grid */
  ctx.strokeStyle='rgba(255,255,255,0.28)'; ctx.lineWidth=0.7;
  for (let i=1;i<3;i++){
    const gx=frmX+(frmW/3)*i, gy=frmY+(frmH/3)*i;
    ctx.beginPath();ctx.moveTo(gx,frmY);ctx.lineTo(gx,frmY+frmH);ctx.stroke();
    ctx.beginPath();ctx.moveTo(frmX,gy);ctx.lineTo(frmX+frmW,gy);ctx.stroke();
  }
  document.getElementById('zoomPct').textContent = Math.round(zoom*100)+'%';
  drawPreview();
}

function drawPreview() {
  if (!adj) return;
  const { imgEl, zoom, panX, panY, frmX, frmY, frmW, frmH } = adj;
  const pv = document.getElementById('tilePreview');
  const PW2 = pv.parentElement.clientWidth||220, PH2=Math.round(PW2/TILE_ASPECT);
  pv.width=PW2; pv.height=PH2;
  const ctx=pv.getContext('2d'); ctx.clearRect(0,0,PW2,PH2);
  ctx.drawImage(imgEl,(frmX-panX)/zoom,(frmY-panY)/zoom,frmW/zoom,frmH/zoom,0,0,PW2,PH2);
}

function bindAdjustEvents() {
  const outer = document.getElementById('cropCanvasOuter');
  const fresh = outer.cloneNode(false);
  while (outer.firstChild) fresh.appendChild(outer.firstChild);
  outer.parentNode.replaceChild(fresh, outer);
  const o = document.getElementById('cropCanvasOuter');

  o.addEventListener('mousedown', e => { e.preventDefault(); adj.dragging=true; adj.lastX=e.clientX; adj.lastY=e.clientY; o.style.cursor='grabbing'; });
  const onMove = e => { if(!adj||!adj.dragging) return; adj.panX+=e.clientX-adj.lastX; adj.panY+=e.clientY-adj.lastY; adj.lastX=e.clientX; adj.lastY=e.clientY; adj.dirty=true; };
  const onUp   = () => { if(adj) adj.dragging=false; const el=document.getElementById('cropCanvasOuter'); if(el) el.style.cursor='grab'; };
  adj._mm=onMove; adj._mu=onUp;
  window.addEventListener('mousemove',onMove); window.addEventListener('mouseup',onUp);

  o.addEventListener('wheel', e => {
    e.preventDefault();
    const rect=o.getBoundingClientRect();
    const raw=e.deltaMode===1?e.deltaY*18:(e.deltaMode===2?e.deltaY*200:e.deltaY);
    zoomAdj(raw<0?1.06:0.945, e.clientX-rect.left, e.clientY-rect.top);
  }, {passive:false});

  let prevDist=null;
  o.addEventListener('touchstart', e=>{e.preventDefault(); if(e.touches.length===1){adj.dragging=true;adj.lastX=e.touches[0].clientX;adj.lastY=e.touches[0].clientY;} if(e.touches.length===2){prevDist=tDist(e.touches);adj.dragging=false;}},{passive:false});
  o.addEventListener('touchmove', e=>{e.preventDefault(); if(e.touches.length===1&&adj.dragging){adj.panX+=e.touches[0].clientX-adj.lastX;adj.panY+=e.touches[0].clientY-adj.lastY;adj.lastX=e.touches[0].clientX;adj.lastY=e.touches[0].clientY;adj.dirty=true;} if(e.touches.length===2&&prevDist){const d=tDist(e.touches);zoomAdj(d/prevDist,...Object.values(tMid(e.touches,o)));prevDist=d;}},{passive:false});
  o.addEventListener('touchend', ()=>{if(adj)adj.dragging=false;prevDist=null;});

  document.getElementById('zoomSlider').oninput = e => {
    const nz=parseFloat(e.target.value); zoomAdj(nz/adj.zoom, adj.cW/2, adj.cH/2);
  };
}

function zoomAdj(factor, ox, oy) {
  if (!adj) return;
  let nz = Math.max(adj.minZoom, Math.min(adj.fillZoom*10, adj.zoom*factor));
  adj.panX=ox-(ox-adj.panX)*(nz/adj.zoom); adj.panY=oy-(oy-adj.panY)*(nz/adj.zoom);
  adj.zoom=nz; document.getElementById('zoomSlider').value=nz; adj.dirty=true;
}
function resetCrop() {
  if (!adj) return;
  const {imgEl,frmX,frmY,frmW,frmH,fillZoom}=adj;
  adj.zoom=fillZoom; adj.panX=frmX-(imgEl.width*fillZoom-frmW)/2; adj.panY=frmY-(imgEl.height*fillZoom-frmH)/2;
  adj.dirty=true; document.getElementById('zoomSlider').value=fillZoom;
}
function saveCrop() {
  if (!adj) return;
  const {idx,zoom,panX,panY,frmX,frmY,frmW,frmH}=adj;
  images[idx].crop = { sx:(frmX-panX)/zoom, sy:(frmY-panY)/zoom, sw:frmW/zoom, sh:frmH/zoom };
  renderGrid(); closeModal(); showToast('Crop saved','success');
}
function closeModal() {
  if (adj) {
    if(adj.raf) cancelAnimationFrame(adj.raf);
    if(adj._mm) window.removeEventListener('mousemove',adj._mm);
    if(adj._mu) window.removeEventListener('mouseup',adj._mu);
    adj=null;
  }
  document.getElementById('adjustModal').classList.add('hidden');
}
function tDist(t) { return Math.hypot(t[0].clientX-t[1].clientX, t[0].clientY-t[1].clientY); }
function tMid(t, el) { const r=el.getBoundingClientRect(); return {x:(t[0].clientX+t[1].clientX)/2-r.left, y:(t[0].clientY+t[1].clientY)/2-r.top}; }

/* ════════════════════════════════════════════════════
   PDF GENERATION
   Page 1: 3-col × 2-row (6 images) + right info panel
   Page 2+: 4-col × 2-row (8 images), "continued" title
════════════════════════════════════════════════════ */
async function generatePDF() {
  /* ── Validation ── */
  const jobNum = document.getElementById('jobNumber').value.trim();
  if (!jobNum) {
    document.getElementById('jobNumber').classList.add('input-error');
    document.getElementById('jobNumError').classList.remove('hidden');
    document.getElementById('jobNumber').focus();
    showToast('Job Number is required','error'); return;
  }
  document.getElementById('jobNumber').classList.remove('input-error');
  document.getElementById('jobNumError').classList.add('hidden');

  if (!images.length) { showToast('Please add at least one image','error'); return; }

  /* Deliverable mandatory check */
  const deliverables = getDeliverables();
  let hasError = false;

  if (!deliverables.length) {
    document.getElementById('deliverableError').classList.remove('hidden');
    if (!hasError) document.querySelector('.deliverable-grid').scrollIntoView({behavior:'smooth', block:'center'});
    hasError = true;
  } else {
    document.getElementById('deliverableError').classList.add('hidden');
  }

  /* Headline mandatory */
  const headline = document.getElementById('headline').value.trim();
  if (!headline) {
    document.getElementById('headlineError').classList.remove('hidden');
    document.getElementById('headline').classList.add('input-error');
    if (!hasError) document.getElementById('headline').scrollIntoView({behavior:'smooth', block:'center'});
    hasError = true;
  } else {
    document.getElementById('headlineError').classList.add('hidden');
    document.getElementById('headline').classList.remove('input-error');
  }

  /* Keywords mandatory */
  const keywords = document.getElementById('keywords').value.trim();
  if (!keywords) {
    document.getElementById('keywordsError').classList.remove('hidden');
    document.getElementById('keywords').classList.add('input-error');
    if (!hasError) document.getElementById('keywords').scrollIntoView({behavior:'smooth', block:'center'});
    hasError = true;
  } else {
    document.getElementById('keywordsError').classList.add('hidden');
    document.getElementById('keywords').classList.remove('input-error');
  }

  if (hasError) { showToast('Please fill in all required fields','error'); return; }

  const date    = document.getElementById('jobDate').value.trim();
  const useJpeg = document.getElementById('useJpeg').checked;

  showProgress(true); setProgress(3,'Initialising…'); await tick();

  if (!window.jspdf?.jsPDF) {
    showProgress(false); showToast('jsPDF not loaded — check connection','error'); return;
  }

  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF({ orientation:'landscape', unit:'mm', format:[PW,PH] });

  /* Load KPMG logo */
  const logoUrl = await safeLoadImg('assets/logo/kpmg-logo.svg') || await safeLoadImg('assets/logo/kpmg-logo.png');

  /* ── PAGE 1 ── */
  setProgress(8,'Generating page 1…'); await tick();
  await pdfPage1(pdf, jobNum, date, deliverables, headline, keywords, images.slice(0,6), logoUrl, useJpeg);

  /* ── SUBSEQUENT PAGES ── */
  const remaining = images.slice(6);
  const extraPages = Math.ceil(remaining.length / 8);
  for (let p=0; p<extraPages; p++) {
    pdf.addPage([PW,PH],'landscape');
    const chunk  = remaining.slice(p*8, p*8+8);
    const startN = 7 + p*8;
    const pct    = 12 + ((p+1)/Math.max(extraPages,1))*84;
    setProgress(pct, `Rendering page ${p+2}…`); await tick();
    await pdfPageContinued(pdf, jobNum, p+2, chunk, startN, logoUrl, useJpeg);
  }

  setProgress(100,'Saving…'); await tick();
  pdf.save(`${jobNum}_ContactSheet.pdf`);
  showProgress(false);
  showToast('Contact sheet downloaded!','success');
}

/* ────────────────────────────────────────────────────
   PAGE 1  layout (based on screenshots exactly)
   Left ~72% : title + 3×2 image grid
   Right ~28% : deliverable info panel
──────────────────────────────────────────────────── */
async function pdfPage1(pdf, jobNum, date, deliverables, headline, keywords, chunk, logoUrl, useJpeg) {
  /* Background: very light blue-grey (matches screenshot) */
  pdf.setFillColor(225, 235, 245);
  pdf.rect(0, 0, PW, PH, 'F');

  /* Right panel background — white */
  const panelX = PW * 0.715;
  const panelW = PW - panelX - 6;
  pdf.setFillColor(255,255,255);
  pdf.roundedRect(panelX, 6, panelW, PH-12, 1.5, 1.5, 'F');
  pdf.setDrawColor(200,210,225); pdf.setLineWidth(0.3);
  pdf.roundedRect(panelX, 6, panelW, PH-12, 1.5, 1.5, 'S');

  /* ── TITLE: "JOBNUMBER Contact sheet" ── */
  pdf.setFont('helvetica','bold');
  pdf.setFontSize(18); pdf.setTextColor(...KPMG_PINK);
  pdf.text(jobNum, 10, 18);
  const jobW = pdf.getTextWidth(jobNum);
  pdf.setTextColor(...KPMG_BLUE);
  pdf.text(' Contact sheet', 10 + jobW, 18);

  /* ── 3-COL × 2-ROW grid ── */
  const imgAreaW = panelX - 10;   /* left margin = 10, gap to panel */
  const COLS3 = 3, ROWS3 = 2;
  const mX3=10, mYtop3=22, mYbot3=16, gX3=6, gY3=8;
  const cellW3 = (imgAreaW - mX3 - gX3*(COLS3-1)) / COLS3;
  const cellH3 = (PH - mYtop3 - mYbot3 - gY3*(ROWS3-1)) / ROWS3;
  const descH3 = 15;   /* 4mm gap + title line + stock ID line */
  const imgH3  = cellH3 - descH3;

  for (let i=0; i<Math.min(chunk.length, 6); i++) {
    const col=i%COLS3, row=Math.floor(i/COLS3);
    const x = mX3 + col*(cellW3+gX3);
    const y = mYtop3 + row*(cellH3+gY3);
    const img = chunk[i];

    /* image cell — white bg */
    pdf.setFillColor(255,255,255);
    pdf.rect(x, y, cellW3, imgH3, 'F');
    pdf.setDrawColor(200,210,225); pdf.setLineWidth(0.2);
    pdf.rect(x, y, cellW3, imgH3, 'S');

    const tc = await renderToCanvas(img, cellW3, imgH3);
    if (tc) {
      const fmt=useJpeg?'JPEG':'PNG', q=useJpeg?0.82:1;
      pdf.addImage(tc.toDataURL(useJpeg?'image/jpeg':'image/png',q), fmt, x, y, cellW3, imgH3);
    }

    /* Below image: clear 4mm gap, then title (bold KPMG blue) + stock ID */
    const descY = y + imgH3 + 4.5;  /* 4.5mm gap between image and first text line */
    const imgTitle   = (img.title || '').trim();
    const stockRaw   = (img.desc  || '').trim();
    const stockMasked = formatMediaId(stockRaw) || 'Adobe Stock or Media ID #xxxxxxxx';

    if (imgTitle) {
      pdf.setFont('helvetica','bold'); pdf.setFontSize(5.2); pdf.setTextColor(...KPMG_BLUE);
      const splitTitle = pdf.splitTextToSize(imgTitle, cellW3);
      pdf.text(splitTitle.slice(0, 2), x, descY);
      const titleLines = Math.min(splitTitle.length, 2);
      /* Stock ID — KPMG blue lighter, below title with 1mm gap */
      pdf.setFont('helvetica','normal'); pdf.setFontSize(4.8);
      pdf.setTextColor(KPMG_BLUE[0], KPMG_BLUE[1], KPMG_BLUE[2], 0.7);
      pdf.text(stockMasked, x, descY + titleLines * 3.0 + 1.5, { maxWidth: cellW3 });
    } else {
      /* No title — stock ID in KPMG blue */
      pdf.setFont('helvetica','bold'); pdf.setFontSize(5.2); pdf.setTextColor(...KPMG_BLUE);
      pdf.text(stockMasked, x, descY, { maxWidth: cellW3 });
    }
  }

  /* ── RIGHT PANEL CONTENT ── */
  const px = panelX + 3.5;
  let py = 10;

  /* "Deliverable" header */
  pdf.setFont('helvetica','bold'); pdf.setFontSize(6.5); pdf.setTextColor(20,30,50);
  pdf.text('Deliverable', px, py);
  pdf.setFont('helvetica','normal'); pdf.setFontSize(5.5); pdf.setTextColor(50,60,80);
  pdf.text('– What will the image be used for (please put an X next to the deliverable):', px + pdf.getTextWidth('Deliverable') + 0.5, py, { maxWidth: panelW - 5 });
  py += 6;

  /* deliverable rows */
  const delivOptions = ['eComms','Web banner','PPT cover','Brochure cover','Slipsheet cover','Other (specify):'];
  delivOptions.forEach(opt => {
    const isChecked = deliverables.some(d => opt.startsWith(d) || (opt==='Other (specify):' && deliverables.some(d2=>!['eComms','Web banner','PPT cover','Brochure cover','Slipsheet cover'].includes(d2))));
    /* box */
    pdf.setFillColor(255,255,255); pdf.setDrawColor(160,170,190); pdf.setLineWidth(0.25);
    pdf.rect(px, py-2.8, 3.5, 3.5, 'FD');
    if (isChecked) { pdf.setFontSize(7); pdf.setTextColor(...KPMG_BLUE); pdf.text('X', px+0.6, py+0.3); }
    pdf.setFont('helvetica','normal'); pdf.setFontSize(5.5); pdf.setTextColor(40,50,70);
    pdf.text(opt === 'Other (specify):' && deliverables.find(d=>!['eComms','Web banner','PPT cover','Brochure cover','Slipsheet cover'].includes(d))
      ? `Other: ${deliverables.find(d=>!['eComms','Web banner','PPT cover','Brochure cover','Slipsheet cover'].includes(d))}`
      : opt, px+4.5, py);
    py += 5.2;
  });
  py += 3;

  /* "What is the headline..." */
  pdf.setFont('helvetica','bold'); pdf.setFontSize(5.8); pdf.setTextColor(20,30,50);
  pdf.text('What is the headline that will accompany the image on the same page?', px, py, { maxWidth: panelW-5 });
  py += 9;
  /* answer box */
  pdf.setFillColor(240,245,252); pdf.setDrawColor(200,210,225); pdf.setLineWidth(0.25);
  pdf.rect(px, py, panelW-5, 16, 'FD');
  if (headline) { pdf.setFont('helvetica','normal'); pdf.setFontSize(5.5); pdf.setTextColor(40,50,70); pdf.text(headline, px+1.5, py+4, { maxWidth: panelW-8 }); }
  py += 20;

  /* "What topic or customer-supplied keywords..." */
  pdf.setFont('helvetica','bold'); pdf.setFontSize(5.8); pdf.setTextColor(20,30,50);
  pdf.text('What topic or customer-supplied keywords should be used for the image search?', px, py, { maxWidth: panelW-5 });
  py += 9;
  /* Keywords box — same fixed height as headline box (16mm) */
  const kwBoxH = 16;
  pdf.setFillColor(240,245,252); pdf.setDrawColor(200,210,225); pdf.setLineWidth(0.25);
  pdf.rect(px, py, panelW-5, kwBoxH, 'FD');
  if (keywords) {
    pdf.setFont('helvetica','normal'); pdf.setFontSize(5.5); pdf.setTextColor(40,50,70);
    pdf.text(keywords, px+1.5, py+4, { maxWidth: panelW-8 });
  }

  /* ── FOOTER ── */
  drawFooter(pdf, logoUrl, null, PW, PH, false);
}

/* ────────────────────────────────────────────────────
   PAGE 2+  layout — 4×2 grid, "continued" heading
──────────────────────────────────────────────────── */
async function pdfPageContinued(pdf, jobNum, pageNum, chunk, startN, logoUrl, useJpeg) {
  pdf.setFillColor(225, 235, 245);
  pdf.rect(0, 0, PW, PH, 'F');

  /* Title */
  pdf.setFont('helvetica','bold'); pdf.setFontSize(16); pdf.setTextColor(...KPMG_PINK);
  pdf.text(jobNum, 10, 16);
  const jobW = pdf.getTextWidth(jobNum);
  pdf.setTextColor(...KPMG_BLUE);
  pdf.text(' Contact sheet, continued', 10 + jobW, 16);

  /* 4×2 grid */
  const COLS4=4, ROWS4=2;
  const mX4=12, mYtop4=20, mYbot4=16, gX4=6, gY4=8;
  const cellW4 = (PW - mX4*2 - gX4*(COLS4-1)) / COLS4;
  const cellH4 = (PH - mYtop4 - mYbot4 - gY4*(ROWS4-1)) / ROWS4;
  const descH4 = 15;   /* 4mm gap + title line + stock ID line */
  const imgH4  = cellH4 - descH4;

  for (let i=0; i<Math.min(chunk.length,8); i++) {
    const col=i%COLS4, row=Math.floor(i/COLS4);
    const x = mX4 + col*(cellW4+gX4);
    const y = mYtop4 + row*(cellH4+gY4);
    const img = chunk[i];
    const num = startN + i;

    /* white cell */
    pdf.setFillColor(255,255,255); pdf.rect(x, y, cellW4, imgH4, 'F');
    pdf.setDrawColor(200,210,225); pdf.setLineWidth(0.2); pdf.rect(x, y, cellW4, imgH4, 'S');

    const tc = await renderToCanvas(img, cellW4, imgH4);
    if (tc) {
      const fmt=useJpeg?'JPEG':'PNG', q=useJpeg?0.82:1;
      pdf.addImage(tc.toDataURL(useJpeg?'image/jpeg':'image/png',q), fmt, x, y, cellW4, imgH4);
    }

    /* Below image: 4.5mm gap then title + stock ID in KPMG colors */
    const descY = y + imgH4 + 4.5;
    const imgTitle   = (img.title || '').trim();
    const stockRaw   = (img.desc  || '').trim();
    const stockMasked = formatMediaId(stockRaw) || 'Adobe Stock or Media ID #xxxxxxxx';

    if (imgTitle) {
      pdf.setFont('helvetica','bold'); pdf.setFontSize(5.2); pdf.setTextColor(...KPMG_BLUE);
      const splitTitle = pdf.splitTextToSize(imgTitle, cellW4);
      pdf.text(splitTitle.slice(0, 2), x, descY);
      const titleLines = Math.min(splitTitle.length, 2);
      pdf.setFont('helvetica','normal'); pdf.setFontSize(4.8);
      pdf.setTextColor(KPMG_BLUE[0], KPMG_BLUE[1], KPMG_BLUE[2], 0.7);
      pdf.text(stockMasked, x, descY + titleLines * 3.0 + 1.5, { maxWidth: cellW4 });
    } else {
      pdf.setFont('helvetica','bold'); pdf.setFontSize(5.2); pdf.setTextColor(...KPMG_BLUE);
      pdf.text(stockMasked, x, descY, { maxWidth: cellW4 });
    }
  }

  drawFooter(pdf, logoUrl, pageNum, PW, PH, true);
}

/* ── FOOTER (KPMG logo + copyright) ── */
function drawFooter(pdf, logoUrl, pageNum, PW, PH, showPageNum) {
  const fy = PH - 11;
  /* thin separator */
  pdf.setDrawColor(180,190,210); pdf.setLineWidth(0.2);
  pdf.line(10, fy, PW-10, fy);

  /* KPMG logo — left */
  if (logoUrl) {
    try { pdf.addImage(logoUrl, 'PNG', 8, fy+1.5, 14, 7); } catch(e){}
  } else {
    /* text fallback */
    pdf.setFont('helvetica','bold'); pdf.setFontSize(9); pdf.setTextColor(...KPMG_BLUE);
    pdf.text('KPMG', 8, fy+6.5);
  }

  /* Copyright text */
  pdf.setFont('helvetica','normal'); pdf.setFontSize(4.2); pdf.setTextColor(80,90,110);
  const copy = '© 2026 KPMG LLP, a Delaware limited liability partnership and a member firm of the KPMG global organisation of independent member firms affiliated with KPMG International Limited, a private English company limited by guarantee. All rights reserved.';
  pdf.text(copy, 25, fy+4.5, { maxWidth: PW - 50 });
  pdf.text('The KPMG name and logo are trademarks used under licence by the independent member firms of the KPMG global organisation.', 25, fy+7.5, { maxWidth: PW - 50 });

  /* Page number — right */
  if (showPageNum && pageNum) {
    pdf.setFont('helvetica','normal'); pdf.setFontSize(7); pdf.setTextColor(80,90,110);
    pdf.text(String(pageNum), PW-8, fy+6);
  }
}

/* ── Format media ID for PDF output:
   - Replace any #<digits> with #XXXXXXXX
   - Replace any standalone 6+ digit number with #XXXXXXXX
   - Keep the rest of the text as-is ── */
function formatMediaId(desc) {
  if (!desc) return '';
  /* Replace #followed by digits */
  let out = desc.replace(/#\d+/g, '#' + 'X'.repeat(8));
  /* Replace bare 6+ digit runs (e.g. from Adobe Stock filenames) */
  out = out.replace(/\d{6,}/g, '#' + 'X'.repeat(8));
  return out;
}

/* ── Render image to canvas for PDF ── */
function renderToCanvas(imgData, wMM, hMM) {
  return new Promise(resolve => {
    try {
      const SCALE = 3.5 * 3.78;
      const W = Math.round(wMM * SCALE), H = Math.round(hMM * SCALE);
      const c = document.createElement('canvas'); c.width=W; c.height=H;
      const ctx = c.getContext('2d');
      const img = new Image();
      img.onload = () => {
        try {
          if (imgData.crop) {
            const cr=imgData.crop; ctx.drawImage(img,cr.sx,cr.sy,cr.sw,cr.sh,0,0,W,H);
          } else {
            const sc=Math.max(W/img.width,H/img.height);
            ctx.drawImage(img,(img.width-W/sc)/2,(img.height-H/sc)/2,W/sc,H/sc,0,0,W,H);
          }
          resolve(c);
        } catch(e){resolve(null);}
      };
      img.onerror=()=>resolve(null); img.src=imgData.dataUrl;
    } catch(e){resolve(null);}
  });
}

/* ── Load asset image ── */
function safeLoadImg(src) {
  return new Promise(resolve => {
    try {
      const img=new Image(); img.crossOrigin='anonymous';
      img.onload=()=>{
        try { const c=document.createElement('canvas');c.width=img.naturalWidth||img.width;c.height=img.naturalHeight||img.height;if(!c.width||!c.height){resolve(null);return;}c.getContext('2d').drawImage(img,0,0);resolve(c.toDataURL('image/png')); }
        catch(e){resolve(null);}
      };
      img.onerror=()=>resolve(null); img.src=src;
    } catch(e){resolve(null);}
  });
}

/* ── Helpers ── */
function tick() { return new Promise(r=>setTimeout(r,16)); }

function showProgress(show) { document.getElementById('progressOverlay').classList.toggle('hidden',!show); }
function setProgress(pct,msg) {
  document.getElementById('progressFill').style.width=pct+'%';
  document.getElementById('progressSub').textContent=msg;
  document.getElementById('progressPct').textContent=Math.round(pct)+'%';
}

let _tt=null;
function showToast(msg,type='') {
  const t=document.getElementById('toast'); t.textContent=msg;
  t.className='toast show'+(type?' '+type:''); clearTimeout(_tt);
  _tt=setTimeout(()=>{t.className='toast';},3000);
}

function mkEl(tag,cls){const e=document.createElement(tag);if(cls)e.className=cls;return e;}
function ico(name) {
  const m={
    sliders:`<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>`,
    x:`<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  };
  return m[name]||'';
}
