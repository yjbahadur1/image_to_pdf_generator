/* ============================================================
   KPMG Creative — Image Options PDF Generator
   app.js  — v3  (dark theme, fixed PDF, full-viewport adjust)
   ============================================================ */
'use strict';

const ASPECT        = 1.0674;  /* cellW/imgAreaH — 16:9 PPT page, 4×2 grid, mX=14 mY=10 gX=gY=5 */
const IMGS_PER_PAGE = 8;
const COLS          = 4;
const ROWS          = 2;

const SERVICE_COVERS = {
  'Digital':               'assets/covers/cover-digital.png',
  'Client Delivery':       'assets/covers/cover-client-delivery.png',
  'Creative Strategy':     'assets/covers/cover-creative-strategy.png',
  'Motion & Illustration': 'assets/covers/cover-motion-illustration.png',
  'Marketing':             'assets/covers/cover-marketing.png',
  'Sales Enablement':      'assets/covers/cover-sales-enablement.png',
};
const THANKYOU_IMG = 'assets/thankyou/thankyou.png';

/* ── STATE ── */
let groups         = [];
let multiGroupMode = false;
let dragSrc        = null;

/*  adj — single mutable object for the Adjust modal  */
let adj = null;
/*  {
      gIdx, iIdx,
      imgEl,            HTMLImageElement
      cW, cH,           canvas pixel dimensions (set from outer div)
      minZoom,          zoom level that exactly fills canvas
      zoom, panX, panY,
      dragging, lastX, lastY,
      raf               requestAnimationFrame id
      dirty             boolean — redraw pending
    }
*/

/* ── BOOT ── */
document.addEventListener('DOMContentLoaded', () => {
  setTodayDate();
  addGroup();
  bindFileInput();
  bindDropZone();
  document.getElementById('toggleMultiGroup').addEventListener('change', e => {
    multiGroupMode = e.target.checked;
    renderGroups();
    document.getElementById('addGroupBtn').style.display = multiGroupMode ? 'inline-flex' : 'none';
    document.getElementById('multiGroupHint').textContent = multiGroupMode
      ? 'Each group gets a keyword title header on its PDF page'
      : 'All images go into one group';
  });
  updateStats();
});

function setTodayDate() {
  const now = new Date();
  document.getElementById('jobDate').value =
    now.toLocaleDateString('en-GB', { day:'numeric', month:'long', year:'numeric' });
  /* sync hidden date picker to today */
  const y = now.getFullYear();
  const m = String(now.getMonth()+1).padStart(2,'0');
  const d = String(now.getDate()).padStart(2,'0');
  document.getElementById('jobDatePicker').value = y+'-'+m+'-'+d;
  /* listen for date picker changes */
  document.getElementById('jobDatePicker').addEventListener('change', e => {
    if (!e.target.value) return;
    const [yr, mo, da] = e.target.value.split('-').map(Number);
    const picked = new Date(yr, mo-1, da);
    document.getElementById('jobDate').value =
      picked.toLocaleDateString('en-GB', { day:'numeric', month:'long', year:'numeric' });
  });
}

/* ══════════════════════════════════════════
   GROUPS
══════════════════════════════════════════ */
function addGroup() {
  groups.push({ id: Date.now() + Math.random(), title: '', images: [] });
  renderGroups();
}

function removeGroup(gIdx) {
  if (groups.length <= 1) { showToast('At least one group is required', 'error'); return; }
  groups.splice(gIdx, 1);
  renderGroups(); updateStats();
}

function renderGroups() {
  const container = document.getElementById('groupsContainer');
  container.innerHTML = '';

  groups.forEach((group, gIdx) => {
    const block = mkEl('div', 'group-block');
    const hdr   = mkEl('div', 'group-header');

    if (multiGroupMode) {
      const badge = mkEl('span', 'group-number');
      badge.textContent = `GROUP ${gIdx + 1}`;

      const inp = mkEl('input', 'group-title-input');
      inp.placeholder = 'Keyword / Group title (required)';
      inp.value = group.title;
      inp.oninput = e => {
        groups[gIdx].title = e.target.value;
        if (e.target.value.trim()) e.target.classList.remove('input-error');
        updateStats();
      };

      const cnt = mkEl('span', 'group-count');
      cnt.textContent = `${group.images.length} img${group.images.length !== 1 ? 's' : ''}`;

      const addB = mkEl('button', 'btn btn-primary btn-sm');
      addB.innerHTML = ico('plus') + ' Add Images';
      addB.onclick = () => triggerFileInput(gIdx);

      const delB = mkEl('button', 'btn btn-ghost btn-sm');
      delB.innerHTML = ico('trash');
      delB.title = 'Remove group';
      delB.onclick = () => removeGroup(gIdx);

      hdr.append(badge, inp, cnt, addB, delB);
    } else {
      const lbl = mkEl('div', 'section-label');
      lbl.textContent = 'Images';
      hdr.appendChild(lbl);
    }

    const body = mkEl('div', 'group-body');
    if (!group.images.length) {
      const empty = mkEl('div', 'group-empty');
      empty.innerHTML = multiGroupMode
        ? 'No images yet — click <strong>Add Images</strong> above'
        : 'Upload images using the button above or drag & drop into the zone';
      body.appendChild(empty);
    } else {
      const grid = mkEl('div', 'image-grid');
      group.images.forEach((imgData, iIdx) => grid.appendChild(buildTile(imgData, gIdx, iIdx)));
      body.appendChild(grid);
    }

    block.append(hdr, body);
    container.appendChild(block);
  });
}

/* ══════════════════════════════════════════
   TILE
══════════════════════════════════════════ */
function buildTile(imgData, gIdx, iIdx) {
  const globalNum = getGlobalIndex(gIdx, iIdx) + 1;

  const tile = mkEl('div', 'img-tile');
  tile.draggable = true;

  tile.addEventListener('dragstart', e => {
    dragSrc = { gIdx, iIdx };
    tile.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
  });
  tile.addEventListener('dragend', () => {
    tile.classList.remove('dragging');
    document.querySelectorAll('.img-tile').forEach(t => t.classList.remove('drag-over-tile'));
  });
  tile.addEventListener('dragover',  e => { e.preventDefault(); tile.classList.add('drag-over-tile'); });
  tile.addEventListener('dragleave', () => tile.classList.remove('drag-over-tile'));
  tile.addEventListener('drop', e => {
    e.preventDefault(); tile.classList.remove('drag-over-tile');
    if (dragSrc && dragSrc.gIdx === gIdx && dragSrc.iIdx !== iIdx) {
      const moved = groups[gIdx].images.splice(dragSrc.iIdx, 1)[0];
      groups[gIdx].images.splice(iIdx, 0, moved);
      renderGroups(); updateStats();
    }
    dragSrc = null;
  });

  const thumb = mkEl('div', 'tile-thumb');
  const cv = document.createElement('canvas');
  thumb.appendChild(cv);
  drawThumb(cv, imgData);

  const numBadge = mkEl('div', 'tile-num');
  numBadge.textContent = globalNum;
  thumb.appendChild(numBadge);

  const nameEl = mkEl('div', 'tile-name');
  nameEl.textContent = imgData.name;
  nameEl.title = imgData.name;

  const acts = mkEl('div', 'tile-actions');
  const adjB = mkEl('button', 'btn btn-outline');
  adjB.innerHTML = ico('sliders') + ' Adjust';
  adjB.onclick = () => openAdjust(gIdx, iIdx);
  const remB = mkEl('button', 'btn btn-danger');
  remB.innerHTML = ico('x') + ' Remove';
  remB.onclick = () => { groups[gIdx].images.splice(iIdx, 1); renderGroups(); updateStats(); };
  acts.append(adjB, remB);

  tile.append(thumb, nameEl, acts);
  return tile;
}

function drawThumb(canvas, imgData) {
  const W = 220, H = Math.round(W / ASPECT);
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext('2d');
  const img = new Image();
  img.onload = () => {
    ctx.clearRect(0, 0, W, H);
    if (imgData.crop) {
      const c = imgData.crop;
      ctx.drawImage(img, c.sx, c.sy, c.sw, c.sh, 0, 0, W, H);
    } else {
      const sc = Math.max(W / img.width, H / img.height);
      ctx.drawImage(img, (img.width - W/sc)/2, (img.height - H/sc)/2, W/sc, H/sc, 0, 0, W, H);
    }
  };
  img.src = imgData.dataUrl;
}

function getGlobalIndex(gIdx, iIdx) {
  let n = 0;
  for (let g = 0; g < gIdx; g++) n += groups[g].images.length;
  return n + iIdx;
}

/* ══════════════════════════════════════════
   FILE INPUT
══════════════════════════════════════════ */
let pendingGroup = 0;
function bindFileInput() {
  const inp = document.getElementById('fileInput');
  inp.addEventListener('change', e => { handleFiles(Array.from(e.target.files), pendingGroup); inp.value = ''; });
}
function triggerFileInput(gIdx) { pendingGroup = gIdx; document.getElementById('fileInput').click(); }
function bindDropZone() {
  const dz = document.getElementById('dropZone');
  dz.addEventListener('click', () => { pendingGroup = 0; document.getElementById('fileInput').click(); });
  dz.addEventListener('dragover',  e => { e.preventDefault(); dz.classList.add('drag-over'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
  dz.addEventListener('drop', e => {
    e.preventDefault(); dz.classList.remove('drag-over');
    handleFiles(Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/')), 0);
  });
}
function handleFiles(files, gIdx) {
  const valid = files.filter(f => f.type.startsWith('image/'));
  if (!valid.length) { showToast('No valid image files', 'error'); return; }
  valid.forEach(file => {
    const r = new FileReader();
    r.onload = ev => {
      groups[gIdx].images.push({ id: Date.now() + Math.random(), name: file.name, dataUrl: ev.target.result, crop: null });
      renderGroups(); updateStats();
    };
    r.readAsDataURL(file);
  });
}

/* ══════════════════════════════════════════
   BULK AUTO-CROP
══════════════════════════════════════════ */
function bulkAutoCrop() {
  const all = groups.flatMap(g => g.images);
  if (!all.length) { showToast('No images to crop', 'error'); return; }
  let done = 0;
  all.forEach(imgData => {
    const img = new Image();
    img.onload = () => {
      const W = img.width, H = img.height, ar = W / H;
      let sw, sh, sx, sy;
      if (ar > ASPECT) { sh = H; sw = H * ASPECT; sx = (W - sw) / 2; sy = 0; }
      else              { sw = W; sh = W / ASPECT; sx = 0; sy = (H - sh) / 2; }
      imgData.crop = { sx, sy, sw, sh };
      if (++done === all.length) { renderGroups(); showToast(`Auto-cropped ${done} images`, 'success'); }
    };
    img.src = imgData.dataUrl;
  });
}

/* ══════════════════════════════════════════
   STATS
══════════════════════════════════════════ */
function updateStats() {
  const total  = groups.reduce((s, g) => s + g.images.length, 0);
  const imgPgs = Math.ceil(total / IMGS_PER_PAGE);
  document.getElementById('statImages').textContent = total;
  document.getElementById('statPages').textContent  = imgPgs;
  document.getElementById('statTotal').textContent  = total > 0 ? 1 + imgPgs + 1 : 0;
}

/* ══════════════════════════════════════════
   ADJUST MODAL  — full-viewport immersive
   Canvas sized to fill available space.
   rAF loop redraws only when dirty.
══════════════════════════════════════════ */
function openAdjust(gIdx, iIdx) {
  /* stop previous loop */
  if (adj && adj.raf) cancelAnimationFrame(adj.raf);
  adj = null;

  document.getElementById('adjustModal').classList.remove('hidden');

  const imgData = groups[gIdx].images[iIdx];
  const img = new Image();
  img.onload = () => {
    const outer  = document.getElementById('cropCanvasOuter');
    const canvas = document.getElementById('cropCanvas');

    /* Canvas fills the whole outer div (dark bg area) */
    const cW = Math.max(outer.clientWidth  || 800, 400);
    const cH = Math.max(outer.clientHeight || 500, 300);
    canvas.width  = cW;
    canvas.height = cH;

    /* Crop FRAME: fixed rect centred in the canvas, sized to tile aspect ratio.
       Leave 15% padding on each side so image area is visible outside frame.  */
    const padX  = cW * 0.15;
    const padY  = cH * 0.15;
    const frmW  = cW - padX * 2;
    const frmH  = frmW / ASPECT;                    /* keep tile aspect */
    /* if frmH > available height, recalc from height */
    const maxFrmH = cH - padY * 2;
    const finalFrmH = Math.min(frmH, maxFrmH);
    const finalFrmW = finalFrmH * ASPECT;
    const frmX  = (cW - finalFrmW) / 2;             /* centre horizontally */
    const frmY  = (cH - finalFrmH) / 2;             /* centre vertically */

    /* zoom so image fills the frame initially */
    const fillZoom = Math.max(finalFrmW / img.width, finalFrmH / img.height);
    const minZoom  = fillZoom * 0.10;               /* can zoom out to 10% of fill */

    let zoom, panX, panY;
    if (imgData.crop) {
      /* Restore: map saved crop sx/sy/sw/sh back to pan/zoom for the frame */
      const c  = imgData.crop;
      zoom     = finalFrmW / c.sw;
      /* image origin: frame top-left - crop offset * zoom */
      panX     = frmX - c.sx * zoom;
      panY     = frmY - c.sy * zoom;
    } else {
      zoom     = fillZoom;
      panX     = frmX - (img.width  * zoom - finalFrmW) / 2;
      panY     = frmY - (img.height * zoom - finalFrmH) / 2;
    }

    adj = { gIdx, iIdx, imgEl: img,
            cW, cH,
            frmX, frmY, frmW: finalFrmW, frmH: finalFrmH,
            fillZoom, minZoom,
            zoom, panX, panY,
            dragging: false, lastX: 0, lastY: 0, raf: null, dirty: true };

    /* init slider */
    const sl = document.getElementById('zoomSlider');
    sl.min   = minZoom;
    sl.max   = fillZoom * 10;
    sl.step  = fillZoom / 2000;
    sl.value = zoom;

    startRenderLoop();
    bindAdjustEvents();
  };
  img.src = imgData.dataUrl;
}

/* rAF render loop ─ only draws when dirty flag set */
function startRenderLoop() {
  function loop() {
    if (!adj) return;
    if (adj.dirty) { drawAdj(); adj.dirty = false; }
    adj.raf = requestAnimationFrame(loop);
  }
  loop();
}

function drawAdj() {
  if (!adj) return;
  const { imgEl, zoom, panX, panY, cW, cH, frmX, frmY, frmW, frmH } = adj;
  const canvas = document.getElementById('cropCanvas');
  const ctx    = canvas.getContext('2d');

  /* 1. Dark background */
  ctx.fillStyle = '#08101e';
  ctx.fillRect(0, 0, cW, cH);

  /* 2. Draw full image wherever it is (can extend outside frame) */
  ctx.save();
  ctx.translate(panX, panY);
  ctx.scale(zoom, zoom);
  ctx.drawImage(imgEl, 0, 0);
  ctx.restore();

  /* 3. Dim overlay outside the crop frame */
  ctx.fillStyle = 'rgba(0,0,0,0.55)';
  ctx.fillRect(0, 0, cW, frmY);                          /* top */
  ctx.fillRect(0, frmY + frmH, cW, cH - frmY - frmH);   /* bottom */
  ctx.fillRect(0, frmY, frmX, frmH);                     /* left */
  ctx.fillRect(frmX + frmW, frmY, cW - frmX - frmW, frmH); /* right */

  /* 4. Crop frame border — white solid */
  ctx.strokeStyle = 'rgba(255,255,255,0.90)';
  ctx.lineWidth   = 1.5;
  ctx.strokeRect(frmX, frmY, frmW, frmH);

  /* 5. 3×3 rule-of-thirds grid inside frame */
  ctx.strokeStyle = 'rgba(255,255,255,0.30)';
  ctx.lineWidth   = 0.7;
  for (let i = 1; i < 3; i++) {
    const gx = frmX + (frmW / 3) * i;
    const gy = frmY + (frmH / 3) * i;
    ctx.beginPath(); ctx.moveTo(gx, frmY); ctx.lineTo(gx, frmY + frmH); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(frmX, gy); ctx.lineTo(frmX + frmW, gy); ctx.stroke();
  }

  document.getElementById('zoomPct').textContent = Math.round(zoom * 100) + '%';
  drawPreview();
}

function drawPreview() {
  if (!adj) return;
  const { imgEl, zoom, panX, panY, frmX, frmY, frmW, frmH } = adj;
  const pv  = document.getElementById('tilePreview');
  const PW  = (pv.parentElement.clientWidth || 224);
  const PH  = Math.round(PW / ASPECT);
  pv.width  = PW;
  pv.height = PH;
  const ctx = pv.getContext('2d');
  ctx.clearRect(0, 0, PW, PH);
  /* Map exactly what is inside the crop frame → preview */
  const srcX = (frmX - panX) / zoom;
  const srcY = (frmY - panY) / zoom;
  const srcW = frmW / zoom;
  const srcH = frmH / zoom;
  ctx.drawImage(imgEl, srcX, srcY, srcW, srcH, 0, 0, PW, PH);
}

/* ── Adjust event binding ── */
function bindAdjustEvents() {
  const outer = document.getElementById('cropCanvasOuter');

  /* clone to remove old listeners */
  const fresh = outer.cloneNode(false);
  while (outer.firstChild) fresh.appendChild(outer.firstChild);
  outer.parentNode.replaceChild(fresh, outer);
  const o = document.getElementById('cropCanvasOuter');

  /* MOUSE — drag to pan */
  o.addEventListener('mousedown', e => {
    e.preventDefault();
    adj.dragging = true;
    adj.lastX = e.clientX; adj.lastY = e.clientY;
    o.style.cursor = 'grabbing';
  });

  /* use window so fast moves don't lose tracking */
  const onMouseMove = e => {
    if (!adj || !adj.dragging) return;
    adj.panX += e.clientX - adj.lastX;
    adj.panY += e.clientY - adj.lastY;
    adj.lastX = e.clientX; adj.lastY = e.clientY;
    clampAdj(); adj.dirty = true;
  };
  const onMouseUp = () => {
    if (adj) adj.dragging = false;
    const el = document.getElementById('cropCanvasOuter');
    if (el) el.style.cursor = 'crosshair';
  };
  /* Store refs on adj so we can clean them up on close */
  adj._mmove = onMouseMove;
  adj._mup   = onMouseUp;
  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('mouseup',   onMouseUp);

  /* WHEEL — smooth zoom toward cursor */
  o.addEventListener('wheel', e => {
    e.preventDefault();
    const rect  = o.getBoundingClientRect();
    const mx    = e.clientX - rect.left;
    const my    = e.clientY - rect.top;
    /* normalise delta across browsers */
    const raw   = e.deltaMode === 1 ? e.deltaY * 18 : (e.deltaMode === 2 ? e.deltaY * 200 : e.deltaY);
    const delta = raw < 0 ? 1.06 : 0.945;
    zoomAdj(delta, mx, my);
  }, { passive: false });

  /* TOUCH — single finger pan, two-finger pinch zoom */
  let prevTouchDist = null;
  o.addEventListener('touchstart', e => {
    e.preventDefault();
    if (e.touches.length === 1) {
      adj.dragging = true;
      adj.lastX = e.touches[0].clientX; adj.lastY = e.touches[0].clientY;
    }
    if (e.touches.length === 2) {
      prevTouchDist = touchDist(e.touches);
      adj.dragging = false;
    }
  }, { passive: false });

  o.addEventListener('touchmove', e => {
    e.preventDefault();
    if (e.touches.length === 1 && adj.dragging) {
      adj.panX += e.touches[0].clientX - adj.lastX;
      adj.panY += e.touches[0].clientY - adj.lastY;
      adj.lastX = e.touches[0].clientX; adj.lastY = e.touches[0].clientY;
      clampAdj(); adj.dirty = true;
    }
    if (e.touches.length === 2 && prevTouchDist) {
      const d   = touchDist(e.touches);
      const mid = touchMid(e.touches, o);
      zoomAdj(d / prevTouchDist, mid.x, mid.y);
      prevTouchDist = d;
    }
  }, { passive: false });

  o.addEventListener('touchend', () => {
    if (adj) adj.dragging = false;
    prevTouchDist = null;
  });

  /* ZOOM SLIDER */
  document.getElementById('zoomSlider').oninput = e => {
    const nz = parseFloat(e.target.value);
    const { cW, cH, zoom } = adj;
    /* zoom around canvas centre */
    zoomAdj(nz / zoom, cW / 2, cH / 2);
    document.getElementById('zoomSlider').value = adj.zoom; /* sync back */
  };
}

function zoomAdj(factor, ox, oy) {
  if (!adj) return;
  const { minZoom, fillZoom } = adj;
  let nz = adj.zoom * factor;
  nz = Math.max(minZoom, Math.min(fillZoom * 10, nz));
  adj.panX = ox - (ox - adj.panX) * (nz / adj.zoom);
  adj.panY = oy - (oy - adj.panY) * (nz / adj.zoom);
  adj.zoom = nz;
  document.getElementById('zoomSlider').value = nz;
  adj.dirty = true;
}

function clampAdj() {
  /* No clamping — image can freely extend outside the frame in all directions.
     The crop frame is fixed; only the image moves underneath it. */
}

function clampAdjFree() { /* free — no clamp */ }

function resetCrop() {
  if (!adj) return;
  const { imgEl, frmX, frmY, frmW, frmH, fillZoom } = adj;
  adj.zoom = fillZoom;
  adj.panX = frmX - (imgEl.width  * fillZoom - frmW) / 2;
  adj.panY = frmY - (imgEl.height * fillZoom - frmH) / 2;
  adj.dirty = true;
  document.getElementById('zoomSlider').value = fillZoom;
}

function saveCrop() {
  if (!adj) return;
  const { gIdx, iIdx, zoom, panX, panY, frmX, frmY, frmW, frmH } = adj;
  /* Crop coords relative to the image — what the frame sees */
  groups[gIdx].images[iIdx].crop = {
    sx: (frmX - panX) / zoom,
    sy: (frmY - panY) / zoom,
    sw: frmW / zoom,
    sh: frmH / zoom,
  };
  renderGroups();
  closeModal();
  showToast('Crop saved', 'success');
}

function closeModal() {
  if (adj) {
    if (adj.raf) cancelAnimationFrame(adj.raf);
    /* clean up window-level listeners */
    if (adj._mmove) window.removeEventListener('mousemove', adj._mmove);
    if (adj._mup)   window.removeEventListener('mouseup',   adj._mup);
    adj = null;
  }
  document.getElementById('adjustModal').classList.add('hidden');
}

function touchDist(t) {
  return Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
}
function touchMid(t, el) {
  const r = el.getBoundingClientRect();
  return { x: (t[0].clientX + t[1].clientX) / 2 - r.left, y: (t[0].clientY + t[1].clientY) / 2 - r.top };
}

/* ══════════════════════════════════════════
   PDF GENERATION
   Fix: safeLoadImg does NOT add ?v= query string
         (breaks file:// URLs).
         Uses CORS-friendly blob approach for
         same-origin assets.
══════════════════════════════════════════ */
async function generatePDF() {
  const allImgs = groups.flatMap(g => g.images);
  if (!allImgs.length) { showToast('Please add at least one image', 'error'); return; }

  /* ── Validation ── */
  const crtInput = document.getElementById('crtNumber');
  const crtError = document.getElementById('crtError');
  if (!crtInput.value.trim()) {
    crtInput.classList.add('input-error');
    crtError.classList.remove('hidden');
    crtInput.focus();
    showToast('CRT Number is required', 'error');
    return;
  }
  crtInput.classList.remove('input-error');
  crtError.classList.add('hidden');

  /* validate group titles when in multi-group mode */
  if (multiGroupMode) {
    for (let i = 0; i < groups.length; i++) {
      if (groups[i].images.length && !groups[i].title.trim()) {
        showToast(`Group ${i+1} needs a keyword/title`, 'error');
        /* highlight the input */
        const inputs = document.querySelectorAll('.group-title-input');
        if (inputs[i]) { inputs[i].classList.add('input-error'); inputs[i].focus(); }
        return;
      }
      document.querySelectorAll('.group-title-input').forEach(el => el.classList.remove('input-error'));
    }
  }

  const crt          = crtInput.value.trim();
  const date         = document.getElementById('jobDate').value.trim();
  const serviceLine  = document.getElementById('serviceLine').value;
  const projectTitle = document.getElementById('projectTitle').value.trim();
  const useJpeg      = document.getElementById('useJpeg').checked;

  showProgress(true);
  setProgress(3, 'Initialising…');
  await tick();

  /* Sanity-check jsPDF loaded */
  if (!window.jspdf || !window.jspdf.jsPDF) {
    showProgress(false);
    showToast('jsPDF library not loaded — check internet connection', 'error');
    return;
  }

  const { jsPDF } = window.jspdf;
  /* PowerPoint Widescreen 16:9 = 338.67mm × 190.5mm — matches your cover/thankyou images exactly */
  const PW = 338.67, PH = 190.5;
  const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: [PW, PH] });

  /* PAGE 1: COVER */
  setProgress(8, 'Generating cover page…');
  await tick();
  await pdfCoverPage(pdf, PW, PH, crt, date, serviceLine, projectTitle, useJpeg);

  /* IMAGE PAGES */
  let pageCount = 0;
  const totalImagePages = groups.reduce((s, g) => s + (g.images.length ? Math.ceil(g.images.length / IMGS_PER_PAGE) : 0), 0);

  for (const group of groups) {
    if (!group.images.length) continue;
    for (let i = 0; i < group.images.length; i += IMGS_PER_PAGE) {
      pdf.addPage([PW, PH], 'landscape');
      pageCount++;
      const chunk  = group.images.slice(i, i + IMGS_PER_PAGE);
      const startN = getGroupGlobalStart(group) + i;
      const title  = multiGroupMode && group.title ? group.title : null;
      const pct    = 10 + (pageCount / Math.max(totalImagePages, 1)) * 78;
      setProgress(pct, `Rendering image page ${pageCount} of ${totalImagePages}…`);
      await tick();
      await pdfImagePage(pdf, PW, PH, chunk, startN, crt, date, title, useJpeg);
    }
  }

  /* LAST PAGE: THANK YOU */
  pdf.addPage([PW, PH], 'landscape');
  setProgress(93, 'Adding thank you page…');
  await tick();
  await pdfThankYouPage(pdf, PW, PH, useJpeg);

  setProgress(100, 'Saving file…');
  await tick();
  pdf.save(`${crt}_ImageOptions_${serviceLine.replace(/\s+/g, '')}.pdf`);
  showProgress(false);
  showToast('PDF downloaded successfully!', 'success');
}

function getGroupGlobalStart(targetGroup) {
  let n = 0;
  for (const g of groups) { if (g.id === targetGroup.id) return n; n += g.images.length; }
  return n;
}

/* ── Cover page ── */
async function pdfCoverPage(pdf, PW, PH, crt, date, sl, projectTitle, useJpeg) {
  const dataUrl = await safeLoadImg(SERVICE_COVERS[sl]);
  if (dataUrl) {
    pdf.addImage(dataUrl, useJpeg ? 'JPEG' : 'PNG', 0, 0, PW, PH);
  } else {
    /* Fallback gradient so PDF doesn't get stuck */
    pdf.setFillColor(8, 12, 28);
    pdf.rect(0, 0, PW, PH, 'F');
    pdf.setFillColor(0, 33, 100);
    pdf.rect(PW - 30, 0, 30, PH, 'F');
    pdf.setTextColor(180, 200, 220);
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(20);
    pdf.text(sl, PW * 0.48, PH / 2, { align: 'center' });
    pdf.setTextColor(80, 100, 130);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(7);
    pdf.text(`[ Place cover at: assets/covers/${sl.toLowerCase().replace(/\s+/g,'-').replace(/&/g,'')}.png ]`, PW / 2, PH / 2 + 10, { align: 'center' });
  }

  /* Overlay: CRT / date / project title — bottom left, 1 line higher */
  const y1 = PH - 28;   /* bottom-left overlay, adjusted for 190.5mm page height */
  pdf.setFont('helvetica', 'bold');
  pdf.setFontSize(10);
  pdf.setTextColor(255, 255, 255);
  pdf.text(crt, 14, y1);

  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(9);
  pdf.setTextColor(220, 230, 245);
  pdf.text(date, 14, y1 + 7);

  if (projectTitle) {
    pdf.setFontSize(8.5);
    pdf.setTextColor(201, 168, 76);
    pdf.text('• ' + projectTitle, 14, y1 + 14);
  }
}

/* ── Image page ── */
async function pdfImagePage(pdf, PW, PH, chunk, startIdx, crt, date, groupTitle, useJpeg) {
  /* white background */
  pdf.setFillColor(255, 255, 255);
  pdf.rect(0, 0, PW, PH, 'F');

  /* Layout: generous equal margins + clean gaps, like screenshot reference */
  /* Top band: CRT/title bar, then equal margins around tile area            */
  const headerH  = groupTitle ? 11 : 8;   /* top bar height */
  const footerH  = 8;                      /* bottom bar height */
  const mX       = 14;                     /* left/right outer margin */
  const mYtop    = 10;                     /* gap from header bar to first tile row */
  const mYbot    = 10;                     /* gap from last tile row to footer bar */
  const gX       = 5;                      /* horizontal gap between tiles */
  const gY       = 5;                      /* vertical gap between tiles */
  const tileAreaW = PW - mX * 2 - gX * (COLS - 1);
  const tileAreaH = PH - headerH - footerH - mYtop - mYbot - gY * (ROWS - 1);
  const cellW    = tileAreaW / COLS;
  const cellH    = tileAreaH / ROWS;

  /* header */
  if (groupTitle) {
    pdf.setFillColor(0, 33, 100);
    pdf.rect(0, 0, PW, headerH, 'F');
    pdf.setTextColor(255, 255, 255);
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(8);
    pdf.text(groupTitle, PW / 2, 8, { align: 'center' });
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(5.5);
    pdf.setTextColor(170, 190, 220);
    pdf.text(crt + '  ' + date, PW - 7, 8, { align: 'right' });
  } else {
    pdf.setFillColor(0, 33, 100);
    pdf.rect(0, 0, PW, 2, 'F');
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(5.5);
    pdf.setTextColor(140, 150, 170);
    pdf.text(crt + '  |  ' + date, PW - 7, 6.5, { align: 'right' });
  }

  /* tiles */
  for (let i = 0; i < chunk.length; i++) {
    const col = i % COLS, row = Math.floor(i / COLS);
    const x   = mX + col * (cellW + gX);
    const y   = headerH + mYtop + row * (cellH + gY);
    const img = chunk[i];
    const num = startIdx + i + 1;

    /* thin cell border */
    pdf.setDrawColor(210, 215, 225);
    pdf.setLineWidth(0.25);
    pdf.rect(x, y, cellW, cellH);

    /* render image — leaves bottom ~5.5mm for filename */
    const imgAreaH = cellH - 5.5;
    const tCanvas  = await renderToCanvas(img, cellW, imgAreaH);
    if (tCanvas) {
      const fmt  = useJpeg ? 'JPEG' : 'PNG';
      const qual = useJpeg ? 0.82 : 1;
      const dUrl = tCanvas.toDataURL(useJpeg ? 'image/jpeg' : 'image/png', qual);
      pdf.addImage(dUrl, fmt, x, y, cellW, imgAreaH);
    }

    /* number badge — top right */
    const numStr = String(num);
    const bW     = 5 + numStr.length * 2.2;
    pdf.setFillColor(0, 33, 100);
    pdf.roundedRect(x + cellW - bW - 1.2, y + 1.2, bW + 0.6, 5.2, 0.8, 0.8, 'F');
    pdf.setTextColor(255, 255, 255);
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(6.5);
    pdf.text(numStr, x + cellW - 2.2, y + 5, { align: 'right' });

    /* filename — bottom right of cell */
    pdf.setTextColor(100, 110, 130);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(4.8);
    pdf.text(trimName(img.name, 34), x + cellW - 1, y + cellH - 1, { align: 'right' });
  }

  /* footer bar */
  pdf.setFillColor(240, 242, 246);
  pdf.rect(0, PH - footerH, PW, footerH, 'F');
  pdf.setTextColor(150, 160, 175);
  pdf.setFontSize(6);
  pdf.setFont('helvetica', 'normal');
  pdf.text('KPMG Creative — Image Options', PW / 2, PH - 2, { align: 'center' });
}

/* ── Thank you page ── */
async function pdfThankYouPage(pdf, PW, PH, useJpeg) {
  const dataUrl = await safeLoadImg(THANKYOU_IMG);
  if (dataUrl) {
    pdf.addImage(dataUrl, useJpeg ? 'JPEG' : 'PNG', 0, 0, PW, PH);
  } else {
    pdf.setFillColor(6, 10, 22);
    pdf.rect(0, 0, PW, PH, 'F');
    pdf.setFillColor(0, 139, 155);
    pdf.rect(0, 0, PW, 3, 'F');
    pdf.setFillColor(10, 40, 100);
    pdf.rect(0, PH - 16, PW, 16, 'F');
    pdf.setTextColor(140, 180, 210);
    pdf.setFontSize(32);
    pdf.setFont('helvetica', 'normal');
    pdf.text('Thank you', PW * 0.5, PH / 2 + 4, { align: 'center' });
    pdf.setTextColor(60, 80, 120);
    pdf.setFontSize(7);
    pdf.text('[ Place thank you image at: assets/thankyou/thankyou.png ]', PW / 2, PH - 8, { align: 'center' });
  }
}

/* ── Render image data to offscreen canvas for PDF ── */
function renderToCanvas(imgData, wMM, hMM) {
  return new Promise(resolve => {
    try {
      const SCALE = 3.5 * 3.78; /* ~96 DPI × scale factor */
      const W = Math.round(wMM * SCALE);
      const H = Math.round(hMM * SCALE);
      const c   = document.createElement('canvas');
      c.width = W; c.height = H;
      const ctx = c.getContext('2d');
      const img = new Image();
      img.onload = () => {
        try {
          if (imgData.crop) {
            const cr = imgData.crop;
            ctx.drawImage(img, cr.sx, cr.sy, cr.sw, cr.sh, 0, 0, W, H);
          } else {
            const sc = Math.max(W / img.width, H / img.height);
            ctx.drawImage(img,
              (img.width  - W / sc) / 2,
              (img.height - H / sc) / 2,
              W / sc, H / sc,
              0, 0, W, H);
          }
          resolve(c);
        } catch (e) { resolve(null); }
      };
      img.onerror = () => resolve(null);
      img.src = imgData.dataUrl;
    } catch (e) { resolve(null); }
  });
}

/* ── Load an asset image (cover / thankyou) as dataURL ──
   KEY FIX: NO query string appended — breaks file:// protocol.
   Resolves null on any failure so PDF never gets stuck.        */
function safeLoadImg(src) {
  return new Promise(resolve => {
    try {
      const img = new Image();
      /* crossOrigin needed only for http; harmless for file:// */
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const c = document.createElement('canvas');
          c.width  = img.naturalWidth  || img.width;
          c.height = img.naturalHeight || img.height;
          if (c.width === 0 || c.height === 0) { resolve(null); return; }
          c.getContext('2d').drawImage(img, 0, 0);
          resolve(c.toDataURL('image/png'));
        } catch (e) { resolve(null); }
      };
      img.onerror = () => resolve(null);
      img.src = src;             /* ← no ?v= cache-buster here */
    } catch (e) { resolve(null); }
  });
}

/* ── Helpers ── */
function trimName(n, max) {
  if (n.length <= max) return n;
  const dot = n.lastIndexOf('.');
  const ext = dot > 0 ? n.slice(dot) : '';
  return n.slice(0, max - ext.length - 1) + '…' + ext;
}

/* yield to browser between heavy operations */
function tick() { return new Promise(r => setTimeout(r, 16)); }

/* ── Progress ── */
function showProgress(show) { document.getElementById('progressOverlay').classList.toggle('hidden', !show); }
function setProgress(pct, msg) {
  document.getElementById('progressFill').style.width = pct + '%';
  document.getElementById('progressSub').textContent  = msg;
  document.getElementById('progressPct').textContent  = Math.round(pct) + '%';
}

/* ── Toast ── */
let _toastTimer = null;
function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className   = 'toast show' + (type ? ' ' + type : '');
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => { t.className = 'toast'; }, 3000);
}

/* ── DOM Utils ── */
function mkEl(tag, cls) { const e = document.createElement(tag); if (cls) e.className = cls; return e; }
function ico(name) {
  const map = {
    plus:    `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
    trash:   `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M9 6V4h6v2"/></svg>`,
    sliders: `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>`,
    x:       `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  };
  return map[name] || '';
}
