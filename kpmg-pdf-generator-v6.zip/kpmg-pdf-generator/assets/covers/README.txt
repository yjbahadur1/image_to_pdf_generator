COVER IMAGES — REPLACE WITH YOUR ACTUAL FILES
==============================================

Place your cover PNG images in this folder with EXACT filenames:

  cover-motion-illustration.png   → Motion & Illustration
  cover-client-delivery.png       → Client Delivery
  cover-marketing.png             → Marketing
  cover-sales-enablement.png      → Sales Enablement
  cover-creative-strategy.png     → Creative Strategy
  cover-digital.png               → Digital

Image requirements:
  - Format: PNG (recommended) or JPG
  - Size: Any — the app will fit it to A4 landscape (1123×794px at 96dpi)
  - The app overlays: CRT Number, Date, Project Title (bottom-left)

You currently have these files from your screenshots:
  cover-BN3d84PG.png  → rename to cover-motion-illustration.png
  cover-CBqtV7I3.png  → rename to cover-client-delivery.png
  cover-DOdkUrot.png  → rename to cover-marketing.png
  cover-DQjpmTL0.png  → rename to cover-sales-enablement.png
  cover-OWTxHmQp.png  → rename to cover-creative-strategy.png
  cover-rSro-nnZ.png  → rename to cover-digital.png
