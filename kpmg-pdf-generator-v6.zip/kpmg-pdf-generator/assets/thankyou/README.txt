THANK YOU IMAGE — REPLACE WITH YOUR ACTUAL FILE
================================================

Place your thank you page PNG image here with EXACT filename:

  thankyou.png

Image requirements:
  - Format: PNG (recommended) or JPG
  - Size: Any — the app will fit it to A4 landscape (1123×794px at 96dpi)
  - This page is placed as the LAST page of every generated PDF

You currently have this file from your screenshots:
  (the "create® Thank you" dark blue image)
  → rename it to: thankyou.png
