KPMG LOGO
=========
Replace kpmg-logo.svg (or kpmg-logo.png) with your official KPMG logo file.
Supported formats: SVG (preferred), PNG, JPG
The logo is displayed at the bottom-left of every PDF page.
